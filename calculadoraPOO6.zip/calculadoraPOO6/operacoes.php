<?php

require_once 'IOperacao.php';

abstract class Operacoes implements IOperacao {

    protected float $num1;
    protected float $num2;

    public function getNum1(): float {
        return $this->num1;
    }

    public function setNum1(float $num1): void {
        $this->num1 = $num1;
    }

    public function getNum2(): float {
        return $this->num2;
    }

    public function setNum2(float $num2): void {
        $this->num2 = $num2;
    }

}